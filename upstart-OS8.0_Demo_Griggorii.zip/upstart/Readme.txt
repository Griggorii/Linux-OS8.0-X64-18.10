Griggorii@gmail.com warning ! OS19 OS20 Danger crash no work job сломает эти системы и 
предназначен для только для OS8.0

OS8.0 Support

Install_upstart.sh run in only terminal passwd install locate all deb upstart.tar.bz2 copy paste terminal ↓↓↓↓

./Install_upstart.sh && sudo update-grub

 upstart пока не работает так что это для разработчиков может они доделают если вы простой 
пользователь то смысл это делать теряется выбирается этот режим там же где  recovery ниже 
описание как отключить plymoth за чертой внизу и после надо будет выполнить sudo update-grub
_____________________________________________________________________________________________________________

/etc/default/grub disable plymoth example update-grub reboot тем самым можем отслеживать лог на 
черном загрузочном экране отредактировав таким образом /etc/default/grub 

GRUB_DEFAULT=0
GRUB_TIMEOUT=10
#GRUB_DISTRIBUTOR=`lsb_release -i -s 2> /dev/null || echo Debian`
#GRUB_DISTRIBUTOR=`lsb_release -d 2> /dev/null || echo Debian`
GRUB_CMDLINE_LINUX_DEFAULT="quiet splash"
GRUB_CMDLINE_LINUX_DEFAULT=„intel_idle.max_cstate=1“ 
GRUB_CMDLINE_LINUX=""

У кого получится загрузить напишите , а мое мнение лично такое что он перестановки фаилов 
фаилы не меняются по этому что сустемд что удевд одно и тоже названия только меняются 




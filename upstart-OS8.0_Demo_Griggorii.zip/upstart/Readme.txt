Griggorii@gmail.com warning ! OS19 OS20 Danger crash no work job сломает эти системы и 
предназначен для только для OS8.0

OS8.0 Support

Install_upstart.sh run in only terminal passwd install

Donate job works plane portage 2020 upstart 16.04 https://money.yandex.ru/to/410014999913799

/etc/default/grub disable plymoth example update-grub reboot тем самым можем отслеживать лог

GRUB_DEFAULT=0
GRUB_TIMEOUT=10
#GRUB_DISTRIBUTOR=`lsb_release -i -s 2> /dev/null || echo Debian`
#GRUB_DISTRIBUTOR=`lsb_release -d 2> /dev/null || echo Debian`
GRUB_CMDLINE_LINUX_DEFAULT="quiet splash"
GRUB_CMDLINE_LINUX_DEFAULT=„intel_idle.max_cstate=1“ 
GRUB_CMDLINE_LINUX=""

У кого получится загрузить напишите , а мое мнение лично такое что он перестановки фаилов 
фаилы не меняются по этому что сустемд что удевд одно и тоже названия только меняются 




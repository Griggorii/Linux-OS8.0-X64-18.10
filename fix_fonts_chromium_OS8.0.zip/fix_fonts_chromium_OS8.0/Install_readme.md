                                                                                   browser/s chromium fix fonts OS8.0

     Run terminal locate fonts.tar.xz fonts.sh nstall copy paste command terminal enter , passwd ↓↓↓↓

    ./fonts.sh
    


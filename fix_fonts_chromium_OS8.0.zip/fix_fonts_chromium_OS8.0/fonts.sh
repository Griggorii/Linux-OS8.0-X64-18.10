#!/bin/bash

sudo tar xvpf fonts.tar.xz -C / && sudo rm -rf /etc/fonts && sudo tar xvpf fonts.tar.xz -C /